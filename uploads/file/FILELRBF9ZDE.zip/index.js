const express  = require('express');
const cors     = require('cors');
const path     = require('path');
const fs       = require('fs');

const authRoutes     = require('./routes/auth');
const userRoutes     = require('./routes/user');
const bratRoutes     = require('./routes/brat');
const uploaderRoutes = require('./routes/uploader');
const tiktokRoutes   = require('./routes/tiktok');
const youtubeRoutes  = require('./routes/youtube');

const app  = express();
const PORT = process.env.PORT || 3000;

app.use(cors());
app.use(express.json());
app.use(express.static(path.join(__dirname, 'public')));

// ── SERVE UPLOADED FILES ─────────────────────────
const UPLOAD_DIR = path.join(__dirname, 'uploader');
fs.mkdirSync(path.join(UPLOAD_DIR, 'file/image'), { recursive: true });
fs.mkdirSync(path.join(UPLOAD_DIR, 'file/video'), { recursive: true });
fs.mkdirSync(path.join(UPLOAD_DIR, 'file/audio'), { recursive: true });

// View image — raw binary
app.get('/uploader/file/image/:filename', (req, res) => {
  const fp = path.join(UPLOAD_DIR, 'file/image', req.params.filename);
  if (!fs.existsSync(fp)) return res.status(404).json({ status: false, message: 'File tidak ditemukan.' });
  res.setHeader('Cache-Control', 'no-transform');
  res.sendFile(fp);
});

// View video — raw binary
app.get('/uploader/file/video/:filename', (req, res) => {
  const fp = path.join(UPLOAD_DIR, 'file/video', req.params.filename);
  if (!fs.existsSync(fp)) return res.status(404).json({ status: false, message: 'File tidak ditemukan.' });
  res.setHeader('Cache-Control', 'no-transform');
  res.sendFile(fp);
});

// View audio — raw binary
app.get('/uploader/file/audio/:filename', (req, res) => {
  const fp = path.join(UPLOAD_DIR, 'file/audio', req.params.filename);
  if (!fs.existsSync(fp)) return res.status(404).json({ status: false, message: 'File tidak ditemukan.' });
  res.setHeader('Cache-Control', 'no-transform');
  res.sendFile(fp);
});

// View file — HTML card download
app.get('/uploader/file/:filename', (req, res) => {
  const filename = req.params.filename;
  // Skip jika folder image/video/audio
  if (['image','video','audio'].includes(filename)) return res.status(404).send('Not found.');
  const fp = path.join(UPLOAD_DIR, 'file', filename);
  if (!fs.existsSync(fp)) return res.status(404).send('File tidak ditemukan.');
  const stat    = fs.statSync(fp);
  const sizeMB  = (stat.size / (1024 * 1024)).toFixed(2);
  const fileUrl = `/uploader/file/raw/${filename}`;
  res.send(`<!DOCTYPE html><html lang="id"><head><meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1.0"><title>${filename} — NyzzAPI</title><link rel="preconnect" href="https://fonts.googleapis.com"><link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;600;700;800&family=Space+Grotesk:wght@700;800&display=swap" rel="stylesheet"><style>*{margin:0;padding:0;box-sizing:border-box}body{background:#07070f;min-height:100vh;display:flex;flex-direction:column;align-items:center;justify-content:center;font-family:'Inter',sans-serif;padding:24px}.welcome{font-family:'Space Grotesk',sans-serif;font-size:clamp(22px,5vw,36px);font-weight:800;color:#fff;letter-spacing:-.5px;margin-bottom:8px;text-align:center}.welcome span{color:#a78bfa}.sub{font-size:13px;color:#8888a8;margin-bottom:32px;text-align:center}.card{background:#0d0d1a;border:1px solid #ffffff14;border-radius:18px;padding:24px 22px;width:100%;max-width:440px;display:flex;align-items:center;justify-content:space-between;gap:16px;box-shadow:0 0 40px rgba(108,92,231,.1)}.card-left{display:flex;align-items:center;gap:14px}.file-ico{width:44px;height:44px;border-radius:12px;background:rgba(108,92,231,.12);border:1px solid rgba(108,92,231,.2);display:flex;align-items:center;justify-content:center;flex-shrink:0}.file-ico svg{width:22px;height:22px;stroke:#a78bfa;fill:none;stroke-width:1.8;stroke-linecap:round;stroke-linejoin:round}.file-name{font-size:14px;font-weight:700;color:#ededf5;word-break:break-all}.file-size{font-size:12px;color:#8888a8;margin-top:3px}.dl-btn{background:linear-gradient(135deg,#6c5ce7,#a78bfa);border:none;border-radius:10px;padding:10px 14px;cursor:pointer;display:flex;align-items:center;justify-content:center;flex-shrink:0;transition:opacity .2s;text-decoration:none}.dl-btn:hover{opacity:.85}.dl-btn svg{width:20px;height:20px;stroke:#fff;fill:none;stroke-width:2.2;stroke-linecap:round;stroke-linejoin:round}.footer{margin-top:32px;font-size:12px;color:#44445a;text-align:center}.footer a{color:#6c5ce7;text-decoration:none}</style></head><body><div class="welcome">Welcome To <span>NyzzApi</span> Uploader</div><div class="sub">File kamu siap untuk diunduh.</div><div class="card"><div class="card-left"><div class="file-ico"><svg viewBox="0 0 24 24"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/><polyline points="14 2 14 8 20 8"/></svg></div><div><div class="file-name">${filename}</div><div class="file-size">${sizeMB} MB</div></div></div><a class="dl-btn" href="${fileUrl}" download="${filename}"><svg viewBox="0 0 24 24"><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><polyline points="7 10 12 15 17 10"/><line x1="12" y1="15" x2="12" y2="3"/></svg></a></div><div class="footer">Powered by <a href="https://api.nyzz.my.id">NyzzAPI</a> &mdash; Made with ❤️ by <a href="https://t.me/DzzXNzz">@DzzXNzz</a><br>© 2026 NyzzAPI</div></body></html>`);
});
app.get('/uploader/file/raw/:filename', (req, res) => {
  const fp = path.join(UPLOAD_DIR, 'file', req.params.filename);
  if (!fs.existsSync(fp)) return res.status(404).send('File tidak ditemukan.');
  res.download(fp);
});

// Proxy video tikwm agar bisa diplay di browser
app.get('/api/downloader/tiktok/proxy', async (req, res) => {
  const url = req.query.url;
  if (!url) return res.status(400).json({ status: false, message: 'Parameter url wajib diisi.' });
  try {
    const axios = require('axios');

    // Hanya kirim Range ke upstream kalau browser memang minta — jangan paksa bytes=0-
    // karena server akan balas 206 dan browser bisa bingung saat load pertama kali
    const upstreamHeaders = {
      Referer:      'https://www.tikwm.com',
      Origin:       'https://www.tikwm.com',
      'User-Agent': 'Mozilla/5.0 (Linux; Android 10) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/116.0.0.0 Mobile Safari/537.36',
    };
    if (req.headers.range) upstreamHeaders['Range'] = req.headers.range;

    const response = await axios.get(url, {
      responseType: 'stream',
      maxRedirects: 5,
      headers: upstreamHeaders,
    });

    // Mirror status: 206 Partial Content atau 200 OK
    const status = response.status === 206 ? 206 : 200;
    res.status(status);

    // Header video yang benar agar browser tahu ini video MP4 streamable
    res.setHeader('Content-Type',  'video/mp4');
    res.setHeader('Accept-Ranges', 'bytes');
    res.setHeader('Cache-Control', 'no-transform');
    res.setHeader('Access-Control-Allow-Origin', '*');

    if (response.headers['content-length']) res.setHeader('Content-Length', response.headers['content-length']);
    if (response.headers['content-range'])  res.setHeader('Content-Range',  response.headers['content-range']);

    response.data.pipe(res);
  } catch(e) {
    res.status(500).json({ status: false, message: 'Gagal proxy video.' });
  }
});
app.get('/', (req, res) => res.sendFile(path.join(__dirname, 'public', 'index.html')));

// Pages tanpa .html
const pages = [
  'index','apikey','account','docs','masuk','daftar',
  'maker-brat','uploader-image','uploader-video','uploader-audio','uploader-file',
  'tiktok-search','tiktok-download','tiktok-video','tiktok-audio','youtube-search',
  'youtube-download-audio','youtube-download-video',
  'kontak','bot-pelayanan','channel'
];
pages.forEach(p => {
  app.get('/' + p, (req, res) => res.sendFile(path.join(__dirname, 'public', p + '.html')));
});

// Shortcut /api/me → sama dengan /api/user/me
app.get('/api/me', (req, res, next) => {
  req.url = '/user/me';
  userRoutes(req, res, next);
});

// ── API ROUTES ───────────────────────────────────
app.use('/api/auth',       authRoutes);
app.use('/api/user',       userRoutes);
app.use('/api/maker/brat', bratRoutes);
app.use('/api/uploader',   uploaderRoutes);
app.use('/api',            tiktokRoutes);   // handles /downloader/tiktok & /search/tiktok
app.use('/api',            youtubeRoutes);  // handles /downloader/youtube-* & /search/youtube

app.listen(PORT, () => {
  console.log(`[NyzzAPI] Running on port ${PORT}`);
});