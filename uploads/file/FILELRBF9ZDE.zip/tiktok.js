const router = require('express').Router();
const axios  = require('axios');
const { apiKeyLimit } = require('../middleware/apikey');

// ── HELPERS ──────────────────────────────────
function formatNumber(integer) {
  return Number(parseInt(integer)).toLocaleString().replace(/,/g, '.');
}

function formatDate(n) {
  const d = new Date(n * 1000);
  return d.toLocaleDateString('en', {
    weekday: 'long', day: 'numeric', month: 'long',
    year: 'numeric', hour: 'numeric', minute: 'numeric', second: 'numeric'
  });
}

// ── DOWNLOAD ─────────────────────────────────
async function tiktokDl(url) {
  const res = await axios.post(
    'https://www.tikwm.com/api/',
    {},
    {
      headers: {
        Accept: 'application/json, text/javascript, */*; q=0.01',
        'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8',
        Origin: 'https://www.tikwm.com',
        Referer: 'https://www.tikwm.com/',
        'User-Agent': 'Mozilla/5.0 (Linux; Android 10) AppleWebKit/537.36 Chrome/116.0.0.0 Mobile Safari/537.36',
        'X-Requested-With': 'XMLHttpRequest'
      },
      params: { url, count: 12, cursor: 0, web: 1, hd: 1 }
    }
  );

  const r = res.data?.data;
  if (!r) throw new Error('Video tidak ditemukan.');

  let data = [];
  if (r?.duration === 0) {
    r.images.forEach(v => data.push({ type: 'photo', url: v }));
  } else {
    data.push(
      { type: 'watermark',       url: 'https://www.tikwm.com' + r?.wmplay  },
      { type: 'nowatermark',     url: 'https://www.tikwm.com' + r?.play    },
      { type: 'nowatermark_hd',  url: 'https://www.tikwm.com' + r?.hdplay  }
    );
  }

  return {
    status:    true,
    title:     r.title,
    taken_at:  formatDate(r.create_time),
    region:    r.region,
    id:        r.id,
    duration:  r.duration + ' Seconds',
    cover:     'https://www.tikwm.com' + r.cover,
    data,
    music_info: {
      id:     r.music_info?.id,
      title:  r.music_info?.title,
      author: r.music_info?.author,
      album:  r.music_info?.album || null,
      url:    'https://www.tikwm.com' + (r.music || r.music_info?.play || '')
    },
    stats: {
      views:    formatNumber(r.play_count),
      likes:    formatNumber(r.digg_count),
      comment:  formatNumber(r.comment_count),
      share:    formatNumber(r.share_count),
      download: formatNumber(r.download_count)
    },
    author: {
      id:       r.author?.id,
      fullname: r.author?.unique_id,
      nickname: r.author?.nickname,
      avatar:   'https://www.tikwm.com' + r.author?.avatar
    }
  };
}

// ── SEARCH ───────────────────────────────────
async function tiktokSearch(query) {
  const res = await axios({
    method: 'POST',
    url: 'https://tikwm.com/api/feed/search',
    headers: {
      'content-type': 'application/x-www-form-urlencoded; charset=UTF-8',
      cookie: 'current_language=en',
      'User-Agent': 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/116.0.0.0 Mobile Safari/537.36'
    },
    data: new URLSearchParams({ keywords: query, count: 12, cursor: 0, web: 1, hd: 1 }).toString()
  });
  return res.data?.data;
}

// ── ROUTES ───────────────────────────────────

// ── /api/downloader/tiktok (lama, tetap ada) ─
router.get('/downloader/tiktok', apiKeyLimit, async (req, res) => {
  const url = req.query.url;
  if (!url) return res.status(400).json({ status: false, message: "Parameter 'url' wajib diisi." });
  try { res.json(await tiktokDl(url)); } catch(e) { res.status(500).json({ status: false, message: e.message }); }
});
router.post('/downloader/tiktok', apiKeyLimit, async (req, res) => {
  const url = req.body?.url;
  if (!url) return res.status(400).json({ status: false, message: "Parameter 'url' wajib diisi." });
  try { res.json(await tiktokDl(url)); } catch(e) { res.status(500).json({ status: false, message: e.message }); }
});

// ── /api/downloader/tiktok-video ─────────────
// Response: status, title, duration, cover, data (video only: wm/nowm/nowm_hd), stats, author
router.get('/downloader/tiktok-video', apiKeyLimit, async (req, res) => {
  const url = req.query.url;
  if (!url) return res.status(400).json({ status: false, message: "Parameter 'url' wajib diisi." });
  try {
    const r = await tiktokDl(url);
    const videos = r.data.filter(d => d.type !== 'photo');
    if (!videos.length) return res.status(400).json({ status: false, message: 'Ini adalah postingan foto, bukan video.' });
    res.json({ status: true, title: r.title, taken_at: r.taken_at, region: r.region,
               duration: r.duration, cover: r.cover, data: videos,
               stats: r.stats, author: r.author });
  } catch(e) { res.status(500).json({ status: false, message: e.message }); }
});
router.post('/downloader/tiktok-video', apiKeyLimit, async (req, res) => {
  const url = req.body?.url;
  if (!url) return res.status(400).json({ status: false, message: "Parameter 'url' wajib diisi." });
  try {
    const r = await tiktokDl(url);
    const videos = r.data.filter(d => d.type !== 'photo');
    if (!videos.length) return res.status(400).json({ status: false, message: 'Ini adalah postingan foto, bukan video.' });
    res.json({ status: true, title: r.title, taken_at: r.taken_at, region: r.region,
               duration: r.duration, cover: r.cover, data: videos,
               stats: r.stats, author: r.author });
  } catch(e) { res.status(500).json({ status: false, message: e.message }); }
});

// ── /api/downloader/tiktok-audio ─────────────
// Response: status, title, music { id, title, author, album, url }
router.get('/downloader/tiktok-audio', apiKeyLimit, async (req, res) => {
  const url = req.query.url;
  if (!url) return res.status(400).json({ status: false, message: "Parameter 'url' wajib diisi." });
  try {
    const r = await tiktokDl(url);
    if (!r.music_info?.url || r.music_info.url === 'https://www.tikwm.com') {
      return res.status(404).json({ status: false, message: 'Audio tidak tersedia untuk video ini.' });
    }
    res.json({ status: true, title: r.title, author: r.author, music: r.music_info });
  } catch(e) { res.status(500).json({ status: false, message: e.message }); }
});
router.post('/downloader/tiktok-audio', apiKeyLimit, async (req, res) => {
  const url = req.body?.url;
  if (!url) return res.status(400).json({ status: false, message: "Parameter 'url' wajib diisi." });
  try {
    const r = await tiktokDl(url);
    if (!r.music_info?.url || r.music_info.url === 'https://www.tikwm.com') {
      return res.status(404).json({ status: false, message: 'Audio tidak tersedia untuk video ini.' });
    }
    res.json({ status: true, title: r.title, author: r.author, music: r.music_info });
  } catch(e) { res.status(500).json({ status: false, message: e.message }); }
});

// ── /api/search/tiktok ───────────────────────
router.get('/search/tiktok', apiKeyLimit, async (req, res) => {
  const query = req.query.query;
  if (!query) return res.status(400).json({ status: false, message: "Parameter 'query' wajib diisi." });
  try { res.json({ status: true, data: await tiktokSearch(query) }); }
  catch(e) { res.status(500).json({ status: false, message: e.message }); }
});
router.post('/search/tiktok', apiKeyLimit, async (req, res) => {
  const query = req.body?.query;
  if (!query) return res.status(400).json({ status: false, message: "Parameter 'query' wajib diisi." });
  try { res.json({ status: true, data: await tiktokSearch(query) }); }
  catch(e) { res.status(500).json({ status: false, message: e.message }); }
});

module.exports = router;
