const API = 'https://api.nyzz.my.id';

const LOGO_SVG = `<svg viewBox="0 0 24 24" fill="none" stroke="#fff" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><polyline points="16 18 22 12 16 6"/><polyline points="8 6 2 12 8 18"/></svg>`;

const API_LIST = [
  { name:'Brat Generator',    category:'Maker',      method:'GET',  endpoint:'/api/maker/brat',              page:'maker-brat.html',        desc:'Generate gambar brat style viral TikTok' },
  { name:'Image Upload',      category:'Uploader',   method:'POST', endpoint:'/api/uploader/image',    page:'uploader-image.html',    desc:'Upload gambar JPG, PNG, JPEG' },
  { name:'Video Upload',      category:'Uploader',   method:'POST', endpoint:'/api/uploader/video',    page:'uploader-video.html',    desc:'Upload video MP4' },
  { name:'Audio Upload',      category:'Uploader',   method:'POST', endpoint:'/api/uploader/audio',    page:'uploader-audio.html',    desc:'Upload audio MP3' },
  { name:'File Upload',       category:'Uploader',   method:'POST', endpoint:'/api/uploader/file',     page:'uploader-file.html',     desc:'Upload semua format file' },
  { name:'TikTok Search',     category:'Search',     method:'GET',  endpoint:'/api/search/tiktok',     page:'tiktok-search.html',     desc:'Cari video TikTok berdasarkan kata kunci' },
  { name:'YouTube Search',    category:'Search',     method:'GET',  endpoint:'/api/search/youtube',    page:'youtube-search.html',    desc:'Cari video YouTube berdasarkan kata kunci' },
  { name:'TikTok Audio',      category:'Downloader', method:'GET',  endpoint:'/api/downloader/tiktok-audio', page:'tiktok-audio.html',   desc:'Ekstrak audio/musik dari video TikTok' },
  { name:'TikTok Video',      category:'Downloader', method:'GET',  endpoint:'/api/downloader/tiktok-video', page:'tiktok-video.html',   desc:'Download video TikTok tanpa watermark HD' },
  { name:'YouTube Audio DL',  category:'Downloader', method:'GET',  endpoint:'/api/downloader/youtube-audio',  page:'youtube-download-audio.html', desc:'Download audio MP3 dari YouTube' },
  { name:'YouTube Video DL',  category:'Downloader', method:'GET',  endpoint:'/api/downloader/youtube-video',  page:'youtube-download-video.html', desc:'Download video YouTube berbagai resolusi' },
];

const SIDEBAR_HTML = `
<nav class="topbar">
  <div class="topbar-left">
    <button class="hamburger" id="hamburger"><span></span><span></span><span></span></button>
    <a href="./index.html" class="logo">
      <div class="logo-icon">${LOGO_SVG}</div>
      <div class="logo-text">Nyzz<em>API</em></div>
    </a>
  </div>
  <div class="topbar-right">
    <div class="status-dot">Online</div>
  </div>
</nav>
<div class="overlay" id="overlay"></div>
<aside class="sidebar" id="sidebar">
  <div class="sidebar-inner">
    <div class="sidebar-search" onclick="openSearch()">
      <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="11" cy="11" r="8"/><line x1="21" y1="21" x2="16.65" y2="16.65"/></svg>
      Search API...
    </div>

    <div class="sidebar-label">Main</div>
    <a class="sidebar-item" href="./index.html" data-page="index.html">
      <span class="s-icon"><svg viewBox="0 0 24 24"><rect x="3" y="3" width="7" height="7"/><rect x="14" y="3" width="7" height="7"/><rect x="3" y="14" width="7" height="7"/><rect x="14" y="14" width="7" height="7"/></svg></span>Dashboard
    </a>
    <a class="sidebar-item" href="./apikey.html" data-page="apikey.html">
      <span class="s-icon"><svg viewBox="0 0 24 24"><circle cx="8" cy="15" r="4"/><path d="M12 15h8M16 11v8"/></svg></span>API Key
    </a>
    <a class="sidebar-item" href="./docs.html" data-page="docs.html">
      <span class="s-icon"><svg viewBox="0 0 24 24"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/><polyline points="14 2 14 8 20 8"/></svg></span>Documentation
    </a>

    <div class="sidebar-divider"></div>
    <div class="sidebar-label">API Categories</div>

    <button class="sidebar-item sidebar-toggle" onclick="toggleGroup('maker')">
      <span class="s-icon"><svg viewBox="0 0 24 24"><circle cx="12" cy="12" r="3"/><path d="M12 1v4M12 19v4M4.22 4.22l2.83 2.83M16.95 16.95l2.83 2.83M1 12h4M19 12h4M4.22 19.78l2.83-2.83M16.95 7.05l2.83-2.83"/></svg></span>
      Maker
      <svg class="chevron" id="chev-maker" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><polyline points="6 9 12 15 18 9"/></svg>
    </button>
    <div class="sidebar-sub" id="group-maker" style="display:none">
      <a class="sidebar-item" href="./maker-brat.html" data-page="maker-brat.html">
        <span class="s-icon"><svg viewBox="0 0 24 24"><path d="M12 2L2 7l10 5 10-5-10-5z"/><path d="M2 17l10 5 10-5"/><path d="M2 12l10 5 10-5"/></svg></span>Brat Generator
      </a>
    </div>

    <button class="sidebar-item sidebar-toggle" onclick="toggleGroup('uploader')">
      <span class="s-icon"><svg viewBox="0 0 24 24"><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><polyline points="17 8 12 3 7 8"/><line x1="12" y1="3" x2="12" y2="15"/></svg></span>
      Uploader
      <svg class="chevron" id="chev-uploader" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><polyline points="6 9 12 15 18 9"/></svg>
    </button>
    <div class="sidebar-sub" id="group-uploader" style="display:none">
      <a class="sidebar-item" href="./uploader-image.html" data-page="uploader-image.html">
        <span class="s-icon"><svg viewBox="0 0 24 24"><rect x="3" y="3" width="18" height="18" rx="2"/><circle cx="8.5" cy="8.5" r="1.5"/><polyline points="21 15 16 10 5 21"/></svg></span>Image Upload
      </a>
      <a class="sidebar-item" href="./uploader-video.html" data-page="uploader-video.html">
        <span class="s-icon"><svg viewBox="0 0 24 24"><polygon points="23 7 16 12 23 17 23 7"/><rect x="1" y="5" width="15" height="14" rx="2"/></svg></span>Video Upload
      </a>
      <a class="sidebar-item" href="./uploader-audio.html" data-page="uploader-audio.html">
        <span class="s-icon"><svg viewBox="0 0 24 24"><path d="M9 18V5l12-2v13"/><circle cx="6" cy="18" r="3"/><circle cx="18" cy="16" r="3"/></svg></span>Audio Upload
      </a>
      <a class="sidebar-item" href="./uploader-file.html" data-page="uploader-file.html">
        <span class="s-icon"><svg viewBox="0 0 24 24"><path d="M22 19a2 2 0 0 1-2 2H4a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h5l2 3h9a2 2 0 0 1 2 2z"/></svg></span>File Upload
      </a>
    </div>

    <button class="sidebar-item sidebar-toggle" onclick="toggleGroup('search')">
      <span class="s-icon"><svg viewBox="0 0 24 24"><circle cx="11" cy="11" r="8"/><line x1="21" y1="21" x2="16.65" y2="16.65"/></svg></span>
      Search
      <svg class="chevron" id="chev-search" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><polyline points="6 9 12 15 18 9"/></svg>
    </button>
    <div class="sidebar-sub" id="group-search" style="display:none">
      <a class="sidebar-item" href="./tiktok-search.html" data-page="tiktok-search.html">
        <span class="s-icon"><svg viewBox="0 0 24 24"><path d="M9 12a4 4 0 1 0 0-8 4 4 0 0 0 0 8zm0 0c0 3 5 6 9 2"/><path d="M15 8c0-1.5 1-3 3-3"/></svg></span>TikTok Search
      </a>
      <a class="sidebar-item" href="./youtube-search.html" data-page="youtube-search.html">
        <span class="s-icon"><svg viewBox="0 0 24 24"><path d="M22.54 6.42a2.78 2.78 0 0 0-1.95-1.96C18.88 4 12 4 12 4s-6.88 0-8.59.46A2.78 2.78 0 0 0 1.46 6.42 29 29 0 0 0 1 12a29 29 0 0 0 .46 5.58A2.78 2.78 0 0 0 3.41 19.6C5.12 20 12 20 12 20s6.88 0 8.59-.46a2.78 2.78 0 0 0 1.95-1.95A29 29 0 0 0 23 12a29 29 0 0 0-.46-5.58z"/><polygon points="9.75 15.02 15.5 12 9.75 8.98 9.75 15.02" fill="currentColor" stroke="none"/></svg></span>YouTube Search
      </a>
    </div>

    <button class="sidebar-item sidebar-toggle" onclick="toggleGroup('downloader')">
      <span class="s-icon"><svg viewBox="0 0 24 24"><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><polyline points="7 10 12 15 17 10"/><line x1="12" y1="15" x2="12" y2="3"/></svg></span>
      Downloader
      <svg class="chevron" id="chev-downloader" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><polyline points="6 9 12 15 18 9"/></svg>
    </button>
    <div class="sidebar-sub" id="group-downloader" style="display:none">
      <a class="sidebar-item" href="./tiktok-audio.html" data-page="tiktok-audio.html">
        <span>TikTok Audio</span>
      </a>
      <a class="sidebar-item" href="./tiktok-video.html" data-page="tiktok-video.html">
        <span>TikTok Video</span>
      </a>
      <a class="sidebar-item" href="./tiktok-download.html" data-page="tiktok-download.html">
        <span class="s-icon"><svg viewBox="0 0 24 24"><path d="M9 12a4 4 0 1 0 0-8 4 4 0 0 0 0 8zm0 0c0 3 5 6 9 2"/><path d="M15 8c0-1.5 1-3 3-3"/></svg></span>TikTok Download
      </a>
      <a class="sidebar-item" href="./youtube-download-audio.html" data-page="youtube-download-audio.html">
        <span class="s-icon"><svg viewBox="0 0 24 24"><path d="M22.54 6.42a2.78 2.78 0 0 0-1.95-1.96C18.88 4 12 4 12 4s-6.88 0-8.59.46A2.78 2.78 0 0 0 1.46 6.42 29 29 0 0 0 1 12a29 29 0 0 0 .46 5.58A2.78 2.78 0 0 0 3.41 19.6C5.12 20 12 20 12 20s6.88 0 8.59-.46a2.78 2.78 0 0 0 1.95-1.95A29 29 0 0 0 23 12a29 29 0 0 0-.46-5.58z"/><polygon points="9.75 15.02 15.5 12 9.75 8.98 9.75 15.02" fill="currentColor" stroke="none"/></svg></span>YouTube Audio
      </a>
      <a class="sidebar-item" href="./youtube-download-video.html" data-page="youtube-download-video.html">
        <span class="s-icon"><svg viewBox="0 0 24 24"><path d="M22.54 6.42a2.78 2.78 0 0 0-1.95-1.96C18.88 4 12 4 12 4s-6.88 0-8.59.46A2.78 2.78 0 0 0 1.46 6.42 29 29 0 0 0 1 12a29 29 0 0 0 .46 5.58A2.78 2.78 0 0 0 3.41 19.6C5.12 20 12 20 12 20s6.88 0 8.59-.46a2.78 2.78 0 0 0 1.95-1.95A29 29 0 0 0 23 12a29 29 0 0 0-.46-5.58z"/><polygon points="9.75 15.02 15.5 12 9.75 8.98 9.75 15.02" fill="currentColor" stroke="none"/></svg></span>YouTube Video
      </a>
    </div>

    <div class="sidebar-divider"></div>
    <div class="sidebar-label">Customer Service</div>

    <a class="sidebar-item" href="./kontak.html" data-page="kontak.html">
      <span class="s-icon"><svg viewBox="0 0 24 24"><path d="M22 16.92v3a2 2 0 0 1-2.18 2 19.79 19.79 0 0 1-8.63-3.07A19.5 19.5 0 0 1 4.69 12 19.79 19.79 0 0 1 1.58 3.4 2 2 0 0 1 3.54 1.21h3a2 2 0 0 1 2 1.72c.127.96.361 1.903.7 2.81a2 2 0 0 1-.45 2.11L7.91 8.73a16 16 0 0 0 6 6l.87-.87a2 2 0 0 1 2.11-.45c.907.339 1.85.573 2.81.7A2 2 0 0 1 21.46 16z"/></svg></span>Kontak
    </a>
    <a class="sidebar-item" href="./bot-pelayanan.html" data-page="bot-pelayanan.html">
      <span class="s-icon"><svg viewBox="0 0 24 24"><rect x="3" y="11" width="18" height="10" rx="2"/><circle cx="12" cy="5" r="2"/><path d="M12 7v4M8 15v1m8-1v1"/></svg></span>Bot Pelayanan
    </a>
    <a class="sidebar-item" href="./channel.html" data-page="channel.html">
      <span class="s-icon"><svg viewBox="0 0 24 24"><path d="M18 8h1a4 4 0 0 1 0 8h-1"/><path d="M2 8h16v9a4 4 0 0 1-4 4H6a4 4 0 0 1-4-4V8z"/><line x1="6" y1="1" x2="6" y2="4"/><line x1="10" y1="1" x2="10" y2="4"/><line x1="14" y1="1" x2="14" y2="4"/></svg></span>Channel Info
    </a>

    <div class="sidebar-divider"></div>
    <div class="sidebar-label">Akun</div>

    <a class="sidebar-item" href="./account.html" data-page="account.html">
      <span class="s-icon"><svg viewBox="0 0 24 24"><path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"/><circle cx="12" cy="7" r="4"/></svg></span>
      <span id="sidebar-account-text">Profil</span>
    </a>
    <div id="sidebar-auth-area"></div>
  </div>
</aside>

<div class="modal-overlay" id="search-modal" onclick="if(event.target===this)closeSearch()">
  <div class="search-popup">
    <div class="search-input-wrap">
      <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="11" cy="11" r="8"/><line x1="21" y1="21" x2="16.65" y2="16.65"/></svg>
      <input id="search-input" placeholder="Cari endpoint, nama, kategori..." oninput="doSearch(this.value)" autocomplete="off"/>
      <button class="search-close-btn" onclick="closeSearch()">ESC</button>
    </div>
    <div class="search-results" id="search-results"></div>
  </div>
</div>`;

function injectSidebar() {
  const wrap = document.getElementById('sidebar-wrap');
  if (wrap) wrap.innerHTML = SIDEBAR_HTML;

  const ham = document.getElementById('hamburger');
  const sb = document.getElementById('sidebar');
  const ov = document.getElementById('overlay');
  if (ham && sb && ov) {
    ham.addEventListener('click', () => {
      sb.classList.toggle('open');
      ham.classList.toggle('active');
      ov.classList.toggle('show');
    });
    ov.addEventListener('click', () => {
      sb.classList.remove('open');
      ham.classList.remove('active');
      ov.classList.remove('show');
    });
  }

  const page = location.pathname.split('/').pop() || 'index.html';
  document.querySelectorAll('.sidebar-item[data-page]').forEach(el => {
    if (el.dataset.page === page) el.classList.add('active');
  });

  updateSidebarAuth();
}

function updateSidebarAuth() {
  const area = document.getElementById('sidebar-auth-area');
  if (!area) return;
  const user = localStorage.getItem('nyzz_user');
  if (user) {
    const u = JSON.parse(user);
    area.innerHTML = `
      <div class="sidebar-user">
        <div class="sidebar-avatar">${u.username[0].toUpperCase()}</div>
        <div class="sidebar-user-info">
          <div class="sidebar-username">${u.username}</div>
          <div class="sidebar-plan">Free Plan</div>
        </div>
      </div>
      <a class="sidebar-item sidebar-logout" onclick="logout()">
        <span class="s-icon"><svg viewBox="0 0 24 24"><path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4"/><polyline points="16 17 21 12 16 7"/><line x1="21" y1="12" x2="9" y2="12"/></svg></span>Keluar
      </a>`;
  } else {
    area.innerHTML = `
      <a class="sidebar-item" href="./masuk.html">
        <span class="s-icon"><svg viewBox="0 0 24 24"><path d="M15 3h4a2 2 0 0 1 2 2v14a2 2 0 0 1-2 2h-4"/><polyline points="10 17 15 12 10 7"/><line x1="15" y1="12" x2="3" y2="12"/></svg></span>Masuk
      </a>
      <a class="sidebar-item" href="./daftar.html">
        <span class="s-icon"><svg viewBox="0 0 24 24"><path d="M16 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"/><circle cx="8.5" cy="7" r="4"/><line x1="20" y1="8" x2="20" y2="14"/><line x1="23" y1="11" x2="17" y2="11"/></svg></span>Daftar
      </a>`;
  }
}
function logout() { localStorage.removeItem('nyzz_token'); localStorage.removeItem('nyzz_user'); window.location.href='./index.html'; }

function toggleGroup(id) {
  const group=document.getElementById('group-'+id); const chev=document.getElementById('chev-'+id); if(!group)return;
  const isOpen=group.style.display!=='none'; group.style.display=isOpen?'none':'block';
  if(chev)chev.style.transform=isOpen?'rotate(0deg)':'rotate(180deg)';
}

function openSearch(){document.getElementById('search-modal')?.classList.add('show');setTimeout(()=>document.getElementById('search-input')?.focus(),80);renderSearchDefault();}
function closeSearch(){document.getElementById('search-modal')?.classList.remove('show');const inp=document.getElementById('search-input');if(inp)inp.value='';}
function renderSearchDefault(){renderResults(API_LIST);}
function doSearch(q){if(!q.trim()){renderSearchDefault();return;}const l=q.toLowerCase();renderResults(API_LIST.filter(a=>a.name.toLowerCase().includes(l)||a.endpoint.toLowerCase().includes(l)||a.category.toLowerCase().includes(l)||a.desc.toLowerCase().includes(l)));}
function renderResults(list){
  const el=document.getElementById('search-results');if(!el)return;
  if(!list.length){el.innerHTML=`<div class="search-empty">Tidak ada hasil</div>`;return;}
  el.innerHTML=list.map(a=>`<a class="search-item" href="${a.page}"><div class="search-item-left"><span class="method-badge ${a.method==='GET'?'method-get':'method-post'}">${a.method}</span><div><div class="search-item-name">${a.name}</div><div class="search-item-ep">${a.endpoint}</div></div></div><div class="search-item-cat">${a.category}</div></a>`).join('');
}

async function trackRequest(){
  const el=document.getElementById('stat-requests');
  const eu=document.getElementById('stat-users');
  const eu2=document.getElementById('stat-uptime');
  try{
    const res=await fetch(`${API}/api/user/stats`); const data=await res.json();
    if(data.status==='sukses'){
      if(el)animateCount(el,data.data.total_requests);
      if(eu)animateCount(eu,data.data.total_users);
    }
    try{
      const ru=await fetch(`${API}/api/uptime`); const du=await ru.json();
      if(eu2&&du.uptime_pct)eu2.textContent=du.uptime_pct;
    }catch{}
  }catch{
    const k='nyzz_total_requests';let c=parseInt(localStorage.getItem(k)||'0')+1;localStorage.setItem(k,c);
    if(el)animateCount(el,c);
  }
}
function animateCount(el,target){let cur=Math.max(0,target-40);const t=setInterval(()=>{cur=Math.min(cur+2,target);el.textContent=cur.toLocaleString();if(cur>=target)clearInterval(t);},16);}

function openModal(id){document.getElementById(id)?.classList.add('show');}
function closeModal(id){document.getElementById(id)?.classList.remove('show');}
document.addEventListener('click',e=>{if(e.target.classList.contains('modal-overlay')&&e.target.id!=='search-modal')e.target.classList.remove('show');});

function switchTab(btn,groupPrefix,tabId){
  btn.closest('.resp-tabs').querySelectorAll('.resp-tab').forEach(t=>t.classList.remove('t-success','t-error'));
  const body=btn.closest('.docs-card-body')||btn.closest('.section');
  body?.querySelectorAll('.resp-content').forEach(c=>c.classList.remove('show'));
  btn.classList.add(tabId.includes('success')?'t-success':'t-error');
  document.getElementById(groupPrefix+'-'+tabId)?.classList.add('show');
}
function copyCode(btn){const pre=btn.closest('.code-block').querySelector('pre.code-body');navigator.clipboard.writeText(pre?.innerText||'').then(()=>{btn.textContent='Copied!';btn.classList.add('copied');setTimeout(()=>{btn.textContent='Copy';btn.classList.remove('copied');},2000);});}

function initUpload(){
  const input=document.getElementById('upload-input'); const zone=document.getElementById('upload-zone'); if(!input||!zone)return;
  input.onchange=()=>{const file=input.files[0];if(!file)return;const r=new FileReader();r.onload=e=>{zone.innerHTML=`<img class="upload-preview" src="${e.target.result}">`;};r.readAsDataURL(file);const res=document.getElementById('upload-result');if(res)res.style.display='none';};
  zone.addEventListener('dragover',e=>{e.preventDefault();zone.classList.add('drag');});
  zone.addEventListener('dragleave',()=>zone.classList.remove('drag'));
  zone.addEventListener('drop',e=>{e.preventDefault();zone.classList.remove('drag');const f=e.dataTransfer.files[0];if(!f)return;const dt=new DataTransfer();dt.items.add(f);input.files=dt.files;input.dispatchEvent(new Event('change'));});
}
async function doUpload(endpoint='/api/uploader/image',fieldName='file',inputId='upload-input',btnId='upload-btn',resultId='upload-result',urlId='upload-url'){
  const input=document.getElementById(inputId); if(!input?.files[0])return alert('Pilih file dulu!');
  const btn=document.getElementById(btnId); const txt=btn.querySelector('.btn-text'); const spn=btn.querySelector('.spinner');
  btn.disabled=true;txt.style.display='none';spn.style.display='block';
  try{
    const apiKey=localStorage.getItem('nyzz_apikey')||prompt('Masukkan API Key kamu:');
    if(!apiKey){btn.disabled=false;txt.style.display='';spn.style.display='none';return;}
    const form=new FormData();form.append(fieldName,input.files[0]);
    const res=await fetch(`${API}${endpoint}?apikey=${apiKey}`,{method:'POST',body:form});
    const data=await res.json();
    if(data.status==='sukses'){document.getElementById(urlId).textContent=data.data.view_url||data.data.url;document.getElementById(resultId).style.display='block';localStorage.setItem('nyzz_apikey',apiKey);}
    else alert('Error: '+data.message);
  }catch(e){alert('Gagal: '+e.message);}
  finally{btn.disabled=false;txt.style.display='';spn.style.display='none';}
}
function copyUrl(btnId='copy-btn',urlId='upload-url'){const url=document.getElementById(urlId)?.textContent;if(!url)return;navigator.clipboard.writeText(url);const btn=document.getElementById(btnId);btn.textContent='✓ Tersalin!';btn.classList.add('copied');setTimeout(()=>{btn.textContent='Salin URL';btn.classList.remove('copied');},2000);}

async function generateBrat(){
  const text=document.getElementById('brat-text')?.value.trim(); if(!text)return alert('Isi teks dulu!');
  const btn=document.getElementById('brat-btn'); const txt=btn.querySelector('.btn-text'); const spn=btn.querySelector('.spinner');
  btn.disabled=true;txt.style.display='none';spn.style.display='block';
  try{
    const apiKey=localStorage.getItem('nyzz_apikey')||prompt('Masukkan API Key kamu:');
    if(!apiKey){btn.disabled=false;txt.style.display='';spn.style.display='none';return;}
    const url=`${API}/api/maker/brat?text=${encodeURIComponent(text)}&apikey=${apiKey}`;
    const res=await fetch(url); if(!res.ok)throw new Error('Gagal generate');
    const blob=await res.blob(); const objUrl=URL.createObjectURL(blob);
    const img=document.getElementById('brat-img'); img.src=objUrl;
    document.getElementById('brat-preview').style.display='block';
    const dl=document.getElementById('brat-download'); dl.href=objUrl; dl.download='brat.png'; dl.style.display='block';
    localStorage.setItem('nyzz_apikey',apiKey);
  }catch(e){alert('Gagal: '+e.message);}
  finally{btn.disabled=false;txt.style.display='';spn.style.display='none';}
}

function cardRedirect(el, url) {
  el.classList.add('card-glow');
  setTimeout(() => { window.open(url, '_blank'); }, 420);
  setTimeout(() => { el.classList.remove('card-glow'); }, 950);
}
